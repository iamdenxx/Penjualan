<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "db_siexp";
$konek = mysqli_connect($server, $username, $password,$database) or die("Gagal konek ke server" .mysqli_connect_error());
if (!$konek) {
    	die("Connection failed: " . mysqli_connect_error());
	}
	?>