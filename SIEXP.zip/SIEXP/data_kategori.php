<?
include_once 'includes/koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>SI.Executive Penjualan</title>
	<link href="asset/css/bootstrap.min.css" rel="stylesheet">
	<link href="asset/css/font-awesome.min.css" rel="stylesheet">
	<link href="asset/css/datepicker3.css" rel="stylesheet">
	<link href="asset/css/styles.css" rel="stylesheet">
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>SIEX</span>PENJUALAN</a>
				<ul class="nav navbar-top-links navbar-right">
					</a>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
				<img src="http://placehold.it/50/30a5ff/fff" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name">Admin</div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		
<!-- SIDE MENU -->

<?php require_once("menu.php"); ?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Data Kategori Barang</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Data Kategori Barang</h1>
			</div>
		</div><!--/.row-->
		
		<!-- Main Dasboard -->
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Data Kategori Barang</div>
					<div class="panel-body">
						<div class="col-md-12">
							<div class="row">
								<div class="col-md-6 text-left">
	</div>
		 <?php include('controler/data_kategori/add_modal.php'); ?>
		<div class="col-md-12 text-left">
			<a href="#addnew" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Tambah Data</a>
		</div>
	</div>
	<br/>

	<table width="50%" class="table table-striped table-bordered" id="tabeldata">
        <thead>
            <tr>
                <th width="5%">No</th>
                <th>Kategori</th>
                <th width="20%">Aksi</th>
            </tr>
        </thead>

        <tfoot>
            <tr>
                <th>No</th>
                <th>Kategori</th>
                <th>Aksi</th>
            </tr>
        </tfoot>

        <tbody>
<?php
$no=1;
$hasil = mysqli_query($konek,"select * from tb_kategori");
	while ($data=mysqli_fetch_array($hasil)) {
?>
            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $data['kategori'] ?></td>
        
                <td class="text-center">
				<a href="#edit<?php echo $data['id_kategori']; ?>" data-toggle="modal" class="btn btn-primary m-r-1em" ><span class="glyphicon glyphicon-edit"></span> </a>
                <a href="#del<?php echo $data['id_kategori']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></a>
              <?php include('controler/data_kategori/button.php'); ?>
			    </td>
            </tr>
<?php
}
?>
        </tbody>
        </table>		
        </div>
        </div>
        </div><!-- /.panel-->
		
			<div class="col-sm-12">
				<p class="back-link">Sistem Informasi Exsecutive Penjualan <span><a>copyright 2019</a></span></p>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
	
	<script src="asset/js/jquery-1.11.1.min.js"></script>
	<script src="asset/js/bootstrap.min.js"></script>
	<script src="asset/js/chart.min.js"></script>
	<script src="asset/js/chart-data.js"></script>
	<script src="asset/js/easypiechart.js"></script>
	<script src="asset/js/easypiechart-data.js"></script>
	<script src="asset/js/bootstrap-datepicker.js"></script>
	<script src="asset/js/custom.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>

<!-- Script Table -->		
    <script>
    	$(document).ready(function() {
    		$('#tabeldata').DataTable();
		});
    </script>
</body>
</html>