<!-- Add New -->
    <div class="modal fade" id="addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Tambah Data Penjualan</h4></center>
                </div>
                <div class="modal-body">
				<div class="container-fluid">
				<form method="POST" action="controler/data_penjualan/addnew.php">
					<div class="row">
						<div class="col-lg-2">
							<label class="control-label" style="position:relative; top:7px;">TGL Transaksi:</label>
						</div>
						<div class="col-lg-10">
							<input type="date" class="form-control" name="tgl_transaksi">
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label class="control-label" style="position:relative; top:7px;">Type Barang:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" class="form-control" id="type_barang" name="type_barang" placeholder="type barang">
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label class="control-label" style="position:relative; top:7px;">Merk:</label>
						</div>
						<div class="col-lg-5">
							<select required class="form-control" id="merk_barang" name="merk_barang">
									<option value="" disabled selected>Pilih Merk Barang</option>;
									<?php  
					                 $query=mysqli_query($konek,"select * from tb_merk");
					                 $data=mysqli_fetch_array($query);
									 echo "<option value='".$data['merk']."'>".$data['merk']."</option>";
									?>
								</select>
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label class="control-label" style="position:relative; top:7px;">Kategori:</label>
						</div>
						<div class="col-lg-5">
							<select required class="form-control" id="kategori_barang" name="kategori_barang">
									<option value="" disabled selected>Pilih Kategori</option>;
									<?php  
					                 $query=mysqli_query($konek,"select * from tb_kategori");
					                 $data=mysqli_fetch_array($query);
									 echo "<option value='".$data['kategori']."'>".$data['kategori']."</option>";
									?>
								</select>
						</div>
					</div>
			           
			        <div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label class="control-label" style="position:relative; top:7px;">Harga:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" class="form-control" id="harga"name="harga" placeholder="harga">
						</div>
					</div>

  					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label class="control-label" style="position:relative; top:7px;">QTY:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" class="form-control" id="qty" name="qty" placeholder="quantity">
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label class="control-label" style="position:relative; top:7px;">Total:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" class="form-control" id="total" name="total" placeholder="total">
						</div>
					</div>

					<div style="height:15px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Jenis Pelanggan:</label>
						</div>
						<div class="col-lg-5">
								<input type="radio" name="jenis_pelanggan" value="Online" checked>
								Online
								<input type="radio" name="jenis_pelanggan" value="Direct">
								Direct
							</div>
						</div>

					<div style="height:15px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Jenis Pembayaran:</label>
						</div>
						<div class="col-lg-5">
								<input type="radio" name="jenis_pembayaran" value="Transfer" checked>
								Transfer
								<input type="radio" name="jenis_pembayaran" value="Cash">
								Cash
							</div>
						</div>

					<div style="height:15px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Status Pembayaran:</label>
						</div>
						<div class="col-lg-5">
								<input type="radio" name="status_pembayaran" value="Lunas" checked>
								Lunas
								<input type="radio" name="status_pembayaran" value="Credit">
								Credit
							</div>
						</div>
                </div> 
				</div>
			 
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</a>
				</form>
          </div>	
         </div>
        </div>
       </div>
       
