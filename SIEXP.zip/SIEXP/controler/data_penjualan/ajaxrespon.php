<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "db_siexp";
$konek = mysqli_connect($server, $username, $password,$database) or die("Gagal konek ke server" .mysqli_connect_error());
if (!$konek) {
    	die("Connection failed: " . mysqli_connect_error());
	}

//respon ajax
	$kode_barang=$_POST['kode_barang']
	$s =mysqli_query("select * from tb_barang where kode_barang='$kode_barang'");
	while ($data = mysqli_fetch($s)){
		echo $data[2];
	}
	?>