<?php
	include('../../includes/koneksi.php');
	


	$tgl=$_POST['tgl_transaksi'];
	
	$type=$_POST['type_barang'];
	$merk=$_POST['merk_barang'];
	$kategori=$_POST['kategori_barang'];
	$harga=$_POST['harga'];
	$qty=$_POST['qty'];
	$total=$_POST['total'];
	$j_pelanggan=$_POST['jenis_pelanggan'];
	$j_pembayaran=$_POST['jenis_pembayaran'];
	$s_pembayaran=$_POST['status_pembayaran'];
	

	mysqli_query($konek,"insert into tb_penjualan (tgl_transaksi, type_barang,merk_barang,kategori_barang,harga,qty,total,jenis_pelanggan,jenis_pembayaran,status_pembayaran) values ('$tgl', '$type','$merk','$kategori','$harga','$qty','$total','$j_pelanggan','$j_pembayaran','$s_pembayaran')");
	header('location:../../data_penjualan.php');
?>
	
