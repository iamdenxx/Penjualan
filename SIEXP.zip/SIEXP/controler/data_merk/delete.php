<?php
	include('../../includes/koneksi.php');
	$id=$_GET['id'];
	mysqli_query($konek,"delete from tb_merk where id_merk='$id'");
	header('location:../../data_merk.php');

?>