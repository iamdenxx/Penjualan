<?php
	include('../../includes/koneksi.php');
	
	$merk=$_POST['merk'];
	

	mysqli_query($konek,"insert into tb_merk (merk) values ('$merk')");
	header('location:../../data_merk.php');
?>