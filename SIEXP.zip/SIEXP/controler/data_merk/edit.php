<?php
	include('../../includes/koneksi.php');

	$id=$_GET['id'];

	$merk=$_POST['merk'];


	mysqli_query($konek,"update tb_merk set merk='$merk' where id_merk='$id'");
	header('location:../../data_merk.php');
    
?>