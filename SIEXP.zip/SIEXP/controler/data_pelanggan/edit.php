<?php
	include('../../includes/koneksi.php');

	$id=$_GET['id'];

	$pelanggan=$_POST['pelanggan'];


	mysqli_query($konek,"update tb_pelanggan set pelanggan='$pelanggan' where id_pelanggan='$id'");
	header('location:../../data_pelanggan.php');
    
?>