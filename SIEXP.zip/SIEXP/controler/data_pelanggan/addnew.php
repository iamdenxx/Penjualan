<?php
	include('../../includes/koneksi.php');
	
	$pelanggan=$_POST['pelanggan'];
	

	mysqli_query($konek,"insert into tb_pelanggan (pelanggan) values ('$pelanggan')");
	header('location:../../data_pelanggan.php');
?>