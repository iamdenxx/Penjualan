<!-- Delete -->
    <div class="modal fade" id="del<?php echo $data['id_barang']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Apakah Anda Akan Menghapus Data Berikut ?</h4></center>
                </div>
                <div class="modal-body">
				<?php
					$del=mysqli_query($konek,"select * from tb_barang where id_barang='".$data['id_barang']."'");
					$drow=mysqli_fetch_array($del);
				?>
				<div class="container-fluid">

					<h5><center>Type Barang</center>
						<strong><center><?php echo $drow['type_barang']; ?></strong></center>
					</h5> 
					<br></br>
					<h5><center>Merk</center>
					<strong><center><?php echo $drow['merk']; ?></strong></center>
				    </h5> 

                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <a href="controler/data_barang/delete.php?id=<?php echo $data['id_barang']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                </div>
				
            </div>
        </div>
    </div>
<!-- /.modal -->

<!-- Edit -->
    <div class="modal fade" id="edit<?php echo $data['id_barang']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel"><b>EDIT DATA BARANG</b></h4></center>
                </div>
                <div class="modal-body">
				<?php
					$edit=mysqli_query($konek,"select * from tb_barang where id_barang='".$data['id_barang']."'");
					$erow=mysqli_fetch_array($edit);
				?>
				<div class="container-fluid">
				<form method="POST" action="controler/data_barang/edit.php?id=<?php echo $erow['id_barang']; ?>">

					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Type Barang:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" name="type_barang" class="form-control" value="<?php echo $erow['type_barang']; ?>">
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Merk:</label>
						</div>
						<div class="col-lg-5">
							<select required class="form-control" name="merk" value="<?php echo $erow['merk']; ?>" >;
									
									<?php  
					                 $query=mysqli_query($konek,"select * from tb_merk");
					                 $data=mysqli_fetch_array($query);
									 echo "<option value='".$data['merk']."'>".$data['merk']."</option>";
									?>
								</select>
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Kategori:</label>
						</div>
						<div class="col-lg-5">
							<select required class="form-control"  name="kategori" value="<?php echo $erow['kategori']; ?>" >;
									
									<?php  
					                 $query=mysqli_query($konek,"select * from tb_kategori");
					                 $data=mysqli_fetch_array($query);
									 echo "<option value='".$data['kategori']."'>".$data['kategori']."</option>";
									?>
								</select>
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label"  style="position:relative; top:7px;">Harga:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" name="harga" class="form-control" value="<?php echo $erow['harga']; ?>">
						</div>
					</div>
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span></span> Save</button>
                </div>
				</form>
            </div>
        </div>
    </div>
<!-- /.modal -->